#ifndef READLINE_H

int read_line(char str[], int n);
#endif
